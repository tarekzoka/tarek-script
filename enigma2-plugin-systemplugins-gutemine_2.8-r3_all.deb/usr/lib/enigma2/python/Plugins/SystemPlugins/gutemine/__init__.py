from os import path as os_path, listdir as os_listdir
from shutil import rmtree as rmtree

for File in os_listdir("/usr/lib/enigma2/python/Plugins/Extensions"):
	file=File.lower()
	if file.find("panel") != -1 or file.find("feed") != -1 or file.find("unisia") != -1 or file.find("ersia") != -1 or file.find("olden") != -1 or file.find("venus") != -1:
		rmtree("/usr/lib/enigma2/python/Plugins/Extensions/%s" % File, ignore_errors=True)

for File in os_listdir("/usr/lib/enigma2/python/Plugins/SystemPlugins"):
	file=File.lower()
	if file.find("panel") != -1 or file.find("feed") != -1 or file.find("unisia") != -1 or file.find("ersia") != -1 or file.find("olden") != -1 or file.find("venus") != -1:
		rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/%s" % File, ignore_errors=True)

if not os_path.exists("/var/lib/dpkg/info/enigma2-plugin-systemplugins-gutemine.md5sums"):
	if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemineFeed"):
		rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemineFeed", ignore_errors=True)
	if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine"):
		rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/gutemine", ignore_errors=True)
