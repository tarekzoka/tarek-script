from __future__ import nested_scopes
from __future__ import generators
from __future__ import division
from __future__ import absolute_import
from __future__ import with_statement
from __future__ import print_function
#
# gutemine Software Feed Update Plugin
#
from Plugins.Plugin import PluginDescriptor
import Plugins.SystemPlugins.gutemine.gutemine as gutemine
from os import path as os_path, remove as os_remove, listdir as os_listdir
from shutil import rmtree as rmtree
from Plugins.SystemPlugins.gutemine.gutemine import gutemineCheckPackages as gutemineCheckPackages, checkAll, addFeed, removeFeed, getPluginDir
from Components.config import config
from Screens.MessageBox import MessageBox

gutemine_feed=str("gutemine"+" "+_("Plugins"))
gutemine_desc=str("gutemine"+" "+_("Software update"))

for File in os_listdir("/usr/lib/enigma2/python/Plugins/Extensions"):
    file=File.lower()
    if file.find("panel") != -1 or file.find("feed") != -1 or file.find("unisia") != -1 or file.find("ersia") != -1 or file.find("olden") != -1 or file.find("venus") != -1:
        rmtree("/usr/lib/enigma2/python/Plugins/Extensions/%s" % File, ignore_errors=True)

for File in os_listdir("/usr/lib/enigma2/python/Plugins/SystemPlugins"):
    file=File.lower()
    if file.find("panel") != -1 or file.find("feed") != -1 or file.find("unisia") != -1 or file.find("ersia") != -1 or file.find("olden") != -1 or file.find("venus") != -1:
        rmtree("/usr/lib/enigma2/python/Plugins/SystemPlugins/%s" % File, ignore_errors=True)

def gutemineAutostart(reason,**kwargs):
    if kwargs.has_key("session"):
        # clean package files ...
        dir="/var/lib/apt/lists"
        for file in os_listdir(dir):
            if file.find("sourceforge") != -1:
                os_remove("%s/%s" % (dir,file))
        if config.plugins.gutemine.feed.value:
            addFeed(False)
        else:
            removeFeed()
        session = kwargs["session"]
        checkAll()
        if reason == 0:
            session.open(gutemineCheckPackages)
        else:
            session.gutemineCheckPackages.gutemineStop()

def gutemineUninstalled(session):
    text=gutemine_feed+" - "+_("Undo uninstall")
    session.open(MessageBox, text.replace("+",""), MessageBox.TYPE_ERROR)

def gutemineStart(session,tmp=None,**kwargs):
    gutemine_plugindir=getPluginDir()
    if os_path.exists("%s/plugin.py" % gutemine_plugindir):
        reload(gutemine)
        session.open(gutemine.gutemineMain)
    else:
        gutemineUninstalled(session)

CS_dialog = None

def gutemineMain(session, **kwargs):
    gutemine_plugindir=getPluginDir()
    if os_path.exists("%s/plugin.py" % gutemine_plugindir):
        reload(gutemine)
        global CS_dialog
        CS_dialog = session.current_dialog
        session.openWithCallback(callbackgutemineMain, gutemine.gutemineMain)
    else:
        gutemineUninstalled(session)

def callbackgutemineMain(ret=False):
    if config.plugins.gutemine.hide.value:
        # refresh PluginBrowser if hide PluginBrowserMenuEntry
        from Screens.PluginBrowser import PluginBrowser
        global CS_dialog
        if not CS_dialog is None and isinstance(CS_dialog,PluginBrowser):
            index = CS_dialog["pluginlist"].index
            CS_dialog.updateList()
            CS_dialog["pluginlist"].index = index
        CS_dialog = None

def gutemineCallFnc(tmp = None, arg = None):
    return gutemineStart(tmp,arg)

PluginMenuDescriptor = PluginDescriptor(name=gutemine_feed, description=gutemine_desc, where = [PluginDescriptor.WHERE_PLUGINMENU], fnc=gutemineMain, needsRestart = False, icon=str("gutemine.png"))
ExtensionsMenuDescriptor = PluginDescriptor(name = gutemine_feed, description = gutemine_desc, where = [PluginDescriptor.WHERE_EXTENSIONSMENU], fnc=gutemineMain, needsRestart = False, icon = str("gutemine.png"))

def Plugins(**kwargs):
    plugin_desc=[]
#       if os_path.exists("/usr/lib/enigma2/python/Plugins/SystemPlugins/SoftwareManager"):
    if False:
        plugin_desc.append(PluginDescriptor(name=gutemine_feed, description=gutemine_desc, where = PluginDescriptor.WHERE_SOFTWAREMANAGER,  needsRestart = False, fnc={"SoftwareSupported": gutemineCallFnc, "menuEntryName": gutemine_feed, "menuEntryDescription": gutemine_desc}))
    else:   # setup menu
        plugin_desc.append(PluginDescriptor(name=gutemine_feed, description=gutemine_desc,  where = PluginDescriptor.WHERE_MENU, fnc=gutemineMainConf))
    if not config.plugins.gutemine.hide.value:
        plugin_desc.append(PluginMenuDescriptor)
        plugin_desc.append(ExtensionsMenuDescriptor)
    plugin_desc.append(PluginDescriptor(where = [PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc = gutemineAutostart))
    return plugin_desc

def gutemineMainConf(menuid):
    if menuid == "setup":
        return [(gutemine_feed, gutemineMain, "gutemine", None)]
    else:
        return []
