#!/bin/sh
#### "*******************************************"
#### "              Created By RAED              *"
#### "*        << Edited by  MOHAMED_OS >>       *"
#### "*        ..:: www.tunisia-sat.com ::..     *"
#### "*******************************************"
# Type: Oscam

/usr/script/oscam_cs.sh stop
sleep 5

rm -rf /usr/bin/oscam
rm -rf /usr/script/oscam_cs.sh
rm -rf /usr/uninstall/oscam_remove.sh
rm -rf /lib/systemd/system/oscam.service
rm -rf /lib/systemd/system/oscam.socket

exit 0
